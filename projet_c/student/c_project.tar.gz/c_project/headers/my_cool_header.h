#ifndef COOL_HEADER_H
#define COOL_HEADER_H

typedef struct
{
    int x;
    int y;
    int b : 1; 
} fancy_struct_t;

int my_func(fancy_struct_t fs);

#endif /* MESSAGE_H */