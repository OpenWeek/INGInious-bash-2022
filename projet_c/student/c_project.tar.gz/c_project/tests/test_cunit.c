#include "../headers/my_cool_header.h"
#include <CUnit/Basic.h>

void test_my_func()
{

    fancy_struct_t fs;
    fs.b = 1;
    for (int i = 0; i < 5; ++i)
    {
        fs.x = i;
        fs.y = (i-2) * 3;
        CU_ASSERT_EQUAL(my_func(fs), i + (i-2) * 3 );
    }
    fs.b = 0;
    for (int i = 0; i < 5; ++i)
    {
        fs.x = i;
        fs.y = i-1;
        CU_ASSERT_EQUAL(my_func(fs), i*i - i);
    }
}

int main()
{
    CU_initialize_registry();
    CU_pSuite suite = CU_add_suite("fancy", 0, 0);
    CU_add_test(suite, "correct_behaviour", test_my_func);

    CU_basic_run_tests();
    CU_basic_show_failures(CU_get_failure_list());
}