#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "headers/my_cool_header.h"

int main(int argc, char *argv[]){
    if(argc < 4){
        printf("Usage: %s op x y\n", argv[0]);
        exit(-1);
    }
    fancy_struct_t fs;
    if(strcasecmp("add", argv[1]) == 0)//perform addition
        fs.b = 1;
    else if (strcasecmp("mult", argv[1]) == 0)//perform multiplication
        fs.b = 0;
    fs.x = atoi(argv[2]);
    fs.y = atoi(argv[3]);

    int res = my_func(fs);

    printf("The result is : %d\n", res);
    exit(0);

}