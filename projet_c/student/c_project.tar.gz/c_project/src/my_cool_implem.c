#include "../headers/my_cool_header.h"

int my_func(fancy_struct_t fs){
    if(fs.b){
        return fs.x + fs.y;
    }
    return fs.x * fs.y;
}